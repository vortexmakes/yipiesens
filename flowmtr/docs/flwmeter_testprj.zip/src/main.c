/*
 *	file: main.c
 *	Last updated for version: 1.0.00
 *	Date of the last update:  Jun 13, 2012
 */

/**
 * 	\file main.c
 *	\brief
 */


#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
#include "flw.h"


#define FOREVER						for(;;)
#define FLW_MX_COMMENT_SIZE			128
#define FLW_MX_SIG_SIZE				256


typedef struct
{
	int size;
	unsigned char value[ FLW_MX_SIG_SIZE ];
} SIG_T;


enum
{
	ERR_EMPTY_FILE,
	ERR_SIG_INCOMPLETE,
	ERR_SIG_TOO_LONG,
	ERR_SIG_WRONG_VALUE,

	NUM_ERRS
};


enum
{
	FLW_IDLE,
	FLW_WS2,
	FLW_S2,
	FLW_WS1,
	FLW_S1
};


static const char *errmsgs[] = 
{
	"\"flwsig\" file is empty"		/* ERR_EMPTY_FILE */
	"signal is incomplete", 		/* ERR_SIG_INCOMPLETE */
	"signal size is too long", 		/* ERR_SIG_TOO_LONG */
	"signal value is wrong" 		/* ERR_SIG_WRONG_VALUE */
};


FILE *flwsig, *flwout;
static int running, state;
static char comment[ FLW_MX_COMMENT_SIZE ], *pc;
static SIG_T s1, s2;
static int nsig, npatt;


static
void
flw_abort( int eno )
{
	running = 0;
	flwprint( "ABORTED: %s\n", errmsgs[ eno ] );
}


static
int
flw_print_comment( FILE *fin, FILE *fout )
{
	pc = comment;
	if( fgets( pc, FLW_MX_COMMENT_SIZE, fin ) == NULL )
	{
		flw_abort( ERR_SIG_INCOMPLETE );
		return FLW_IDLE;
	}
	*(pc + strlen( pc ) - 1) = '\0';
	return FLW_WS1;
}


static
void
flw_store_sig_value( SIG_T *sig, int val )
{
	if( sig->size <= FLW_MX_SIG_SIZE )
		sig->value[ sig->size++ ] = val - 48;
	else
		flw_abort( ERR_SIG_TOO_LONG );
}


static
void
flw_eof( void )
{
	running = 0;
	flwprint( "\n\n\nEnd of file reached.\nEscape to quit..." );
}


static
void
flw_proc_sig( SIG_T *sig1, SIG_T *sig2 )
{
	int i;
	unsigned char sig;

	nsig = sig1->size >= sig2->size ? sig2->size : sig1->size;
	++npatt;
	flwprint( "\nPattern [%d] -> samples %d \"%s\"\n\n", 	npatt, 
													nsig, 
													pc != NULL ? pc : ""  );

	for( i = 0; i < nsig; ++i )
	{
		sig = 0;
		sig = sig | ( sig1->value[ i ] ? 2 : 0 );
		sig = sig | ( sig2->value[ i ] ? 1 : 0 );
		flwprint( "[%3d] %d %d",	i, 
									sig1->value[ i ], 
									sig2->value[ i ], 
									sig );
		flw_process( S1S2, sig );
		flwprint( "\n" );
	}
}


int
main( int argc, char *argv[] )
{
	int c;

	(void)argc;
	(void)argv;

	if( ( flwsig = fopen( "../flwsig.txt", "r+" ) ) == NULL )
	{
		perror( "Can't open file \"flwsig.txt\"\n" );
		exit( EXIT_FAILURE );
	}

	if( ( flwout = fopen( "../flwout.txt", "w+" ) ) == NULL )
	{
		perror( "Can't open file \"flwout.txt\"\n" );
		exit( EXIT_FAILURE );
	}

	flwprint( "---- Flowmeter evaluation " );
	flwprint( "date : "__DATE__" - "__TIME__"----\n\n\n" );

	state = FLW_IDLE;
	running = 1;
	npatt = 0;
	pc = NULL;	
	flw_init();

	/* Process the input file */

	do
	{
		c = fgetc( flwsig );
		switch( state )
		{
			case FLW_IDLE:
				if( c == EOF )
					flw_eof();
				else if( c == '#' )
					state = flw_print_comment( flwsig, flwout );
				else if( c == '+' )
					state = FLW_S1;
				break;
			case FLW_WS1:
				if( c == EOF )
					flw_abort( ERR_EMPTY_FILE );
				else if( c == '#' )
					state = flw_print_comment( flwsig, flwout );
				else if( c == '+' )
				{
					nsig = s2.size = s1.size = 0;
					state = FLW_S1;
				}
				break;
			case FLW_S1:
				if( c == EOF )
					flw_abort( ERR_EMPTY_FILE );
				else if( c == '1' || c == '0' )
					flw_store_sig_value( &s1, c );
				else if( c == '\n' )
					state = FLW_WS2;
				else
					flw_abort( ERR_SIG_WRONG_VALUE );
				break;
			case FLW_WS2:
				if( c == EOF )
					flw_abort( ERR_EMPTY_FILE );
				else if( c == '#' )
					state = flw_print_comment( flwsig, flwout );
				else if( c == '+' )
				{
					s2.size = 0;
					state = FLW_S2;
				}
				break;
			case FLW_S2:
				if( c == EOF )
					flw_abort( ERR_EMPTY_FILE );
				else if( c == '1' || c == '0' )
					flw_store_sig_value( &s2, c );
				else if( c == '\n' )
				{
					flw_init();
					flw_proc_sig( &s1, &s2 );
					pc = NULL;
					state = FLW_IDLE;
				}
				else
					flw_abort( ERR_SIG_WRONG_VALUE );
				break;
			default:
				break;
		}
	}
	while( running );

	_getche();
	fclose( flwsig );
	fclose( flwout );
}
